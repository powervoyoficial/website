<p>{{trans('lang.send_email_1')}} {{ $data['name'] }}</p>
<p>{{trans('lang.send_email_2')}} {{ $data['message'] }}.</p>
<p>{{trans('lang.send_email_3')}}</p>