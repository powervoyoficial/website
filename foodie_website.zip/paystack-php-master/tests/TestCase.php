<?php
/**
 * Created by PhpStorm.
 * User: perfectmak
 * Date: 2/12/16
 * Time: 4:14 PM
 */

namespace PaystackTest;


use PHPUnit_Framework_TestCase;

class TestCase extends PHPUnit_Framework_TestCase
{

}