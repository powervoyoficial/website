<?php
/**
 * Created by PhpStorm.
 * User: perfectmak
 * Date: 2/12/16
 * Time: 4:12 PM
 */

namespace PaystackTest;


class CustomerTest extends TestCase
{
    public function testCustomerCreation()
    {
        $this->assertEquals(true,true);
    }
}