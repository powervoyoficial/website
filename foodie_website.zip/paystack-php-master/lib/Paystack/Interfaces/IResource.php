<?php

namespace Paystack\Interfaces;


interface IResource
{

}

?>