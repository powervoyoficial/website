<?php

namespace Paystack;

use Paystack\Interfaces\IResource;

class Subscription implements IResource
{

}

?>